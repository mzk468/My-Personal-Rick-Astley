# My Personal Rick Astley - A Rick Astley themed "AI"

## Made during Royal Hackaway V6, 2023.

## Instructions

Run BOTH the brain.py files and face.py files, and enter your inputs in the command line window!

## Prerequisites

Make sure the following libraries are installed:

`playsound`
`pyttsx3`
`pygame`

You can install them all with the command ```pip install playsound pyttsx3 pygame```
